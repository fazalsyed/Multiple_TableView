//
//  Header.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 07/04/23.
//

import UIKit

class Header: UITableViewHeaderFooterView {

    @IBOutlet var myimg: UIImageView!
    @IBOutlet var mylbl: UILabel!
    @IBOutlet var myView: UIView!
}

