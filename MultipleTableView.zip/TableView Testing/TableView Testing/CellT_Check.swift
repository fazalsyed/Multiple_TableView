//
//  CellT_Check.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 08/04/23.
//

import UIKit

class CellT_Check: UITableViewCell {

    @IBOutlet var mylbl: UILabel!
    @IBOutlet var mylbl1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
