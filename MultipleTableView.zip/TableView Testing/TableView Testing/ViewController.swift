//
//  ViewController.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 07/04/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var mytable: UITableView!
    @IBOutlet var citytableView: UITableView!
    @IBOutlet var CountryTableView: UITableView!
    var nameArrya : [String] = ["fazal","abbas","Syed","Hasan","Ali"]
    var cityArry : [String] = ["Luccknow","punjab","delhi","ludhiana","aligarh"]
    var countryArry : [String] = ["America","Canda","India","Pakistan","Finland"]
    override func viewDidLoad() {
        super.viewDidLoad()
        mytable.delegate = self
        mytable.dataSource = self
        citytableView.delegate = self
        citytableView.dataSource = self
        CountryTableView.delegate = self
        CountryTableView.dataSource = self
        mytable.tag = 0
        citytableView.tag = 1
        CountryTableView.tag = 2
        mytable.register(UINib(nibName: "Header", bundle: nil), forHeaderFooterViewReuseIdentifier: "Header")
        citytableView.register(UINib(nibName: "Header2", bundle: nil), forHeaderFooterViewReuseIdentifier: "Header2")
        CountryTableView.register(UINib(nibName: "Header", bundle: nil),forHeaderFooterViewReuseIdentifier: "Header")
        mytable.register(UINib(nibName: "FooterView", bundle: nil),forHeaderFooterViewReuseIdentifier: "FooterView")
        citytableView.register(UINib(nibName: "FooterView", bundle: nil),forHeaderFooterViewReuseIdentifier: "FooterView")
        CountryTableView.register(UINib(nibName: "FooterView", bundle: nil),forHeaderFooterViewReuseIdentifier: "FooterView")
        mytable.register(UINib(nibName: "CellT_Check", bundle: nil),forCellReuseIdentifier: "CellT_Check")
    }
    
    @IBAction func isEditing(_ sender: UIButton) {
            if mytable.isEditing{
                mytable.isEditing = true
            }
            else{
                mytable.isEditing = false
            }
        }
    }
extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView.tag{
        case 0:
            return nameArrya.count
        case 1 :
            return cityArry.count
        case 2:
            return countryArry.count
        default:
            return 1
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch tableView.tag{
        case 0:
            if (indexPath.row == 0) || (indexPath.row  == 2){
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Testing", for: indexPath)as? CellT_Testing
                cell?.mylbl?.text = nameArrya[indexPath.row]
                cell?.mylbl?.textAlignment = .center
                cell?.mylbl.textColor = .purple
                return cell!
            }
            else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Check", for: indexPath)as? CellT_Check
                cell?.mylbl1.text = countryArry[indexPath.row]
                cell?.mylbl?.text = cityArry[indexPath.row]
                if(indexPath.row == 1){
                    cell?.mylbl1.isHidden = true
                    cell?.mylbl.isHidden = false
                    cell?.mylbl?.textAlignment = .center
                    cell?.mylbl.textColor = .darkGray
                }
                else{
                    cell?.mylbl1.isHidden = false
                    cell?.mylbl.isHidden = false
                    cell?.mylbl?.textAlignment = .center
                    cell?.mylbl.textColor = .darkGray
                }
                return cell!
                
            }
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_City", for: indexPath)as? CellT_City
            cell?.lblCity?.text = cityArry[indexPath.row]
            cell?.lblCity?.textAlignment = .center
            return cell!
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_Country", for: indexPath)as? CellT_Country
            cell?.lblCountry?.text = countryArry[indexPath.row]
            cell?.lblCountry?.textAlignment = .center
            return cell!
        default:
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch tableView.tag{
        case 0:
            return "Name"
        case 1:
            return "City"
        case 2:
            return "Country"
        case 3:
            return "Header 4"
        default:
            return ""
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch tableView.tag{
        case 0:
            return 30
        case 1:
            return 30
        case 2:
            return 30
        case 3:
            return 30
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch tableView.tag{
        case 0:
            let headerView = mytable.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
            headerView.mylbl.text = "Hii"
            return headerView
        case 1:
            let headerView = citytableView.dequeueReusableHeaderFooterView(withIdentifier: "Header2") as! Header2
            headerView.mylbl.text = "CHECK"
            return headerView
        case 2:
            let headerView = mytable.dequeueReusableHeaderFooterView(withIdentifier: "Header") as! Header
            headerView.mylbl.text = "TESTING"
            return headerView
        default:
            return UITableViewCell()
        }
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        switch tableView.tag{
        case 0:
            let cell = mytable.dequeueReusableHeaderFooterView(withIdentifier: "FooterView") as! FooterView
            cell.mylbl.text = "First Footter"
            return cell
        case 1:
            let cell = citytableView.dequeueReusableHeaderFooterView(withIdentifier: "FooterView") as! FooterView
            cell.mylbl.text = "Seconder Footter"
            return cell
        case 2:
            let cell = CountryTableView.dequeueReusableHeaderFooterView(withIdentifier: "FooterView") as! FooterView
            cell.mylbl.text = "Third Footter"
            return cell
        default:
            return UITableViewCell()
        }
    }
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        switch tableView.tag{
        case 0:
            return 30
        case 1:
            return 30
        case 2:
            return 30
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        switch tableView.tag{
        case 0:
            return 30
        case 1:
            return 30
        case 2:
            return 30
        case 3:
            return 30
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch tableView.tag{
        case 0:
            return 30
        case 1:
            return 90
        case 2:
            return 70
        case 3 :
            return 60
        default:
            return 0
        }
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        switch tableView.tag{
        case 0:
            return "Footer 1"
        case 1:
            return "Footer 2"
        case 3:
            return "Footer 3"
        default:
            return ""
        }
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if (indexPath.row == 0) || (indexPath.row == 3) || (indexPath.row == 5){
            let cell = mytable.dequeueReusableCell(withIdentifier: "CellT_Check") as! CellT_Check
            cell.mylbl.textColor = .red
        }
        else{
            let cell = mytable.dequeueReusableCell(withIdentifier: "CellT_Check") as! CellT_Check
            cell.mylbl.textColor = .green
        }
    }
    func tableView(_ tableView: UITableView, willDisplayFooterView view: UIView, forSection section: Int) {
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, _ in
            self.nameArrya.remove(at: indexPath.row)
            self.mytable.deleteRows(at: [indexPath], with: .fade)
        }
        
        let editAction = UIContextualAction(style: .normal, title: "Edit") { _, _, _ in
            let alertcontroller = UIAlertController(title: "Edit", message: nil, preferredStyle: .alert)
            alertcontroller.addTextField(configurationHandler: { (textfield) in
                textfield.text = self.nameArrya[indexPath.row]
            })
            let cancelbtn = UIAlertAction(title: "Cancel", style: .cancel)
            let savebtn = UIAlertAction(title: "Save", style: .default ,handler: { (action) in
                let textfield = alertcontroller.textFields![0]
                self.nameArrya[indexPath.row] = textfield.text!
                tableView.reloadRows(at: [indexPath], with: .fade)
            })
            alertcontroller.addAction(cancelbtn)
            alertcontroller.addAction(savebtn)
            self.present(alertcontroller, animated: true)
        }
        let shareAction = UIContextualAction(style: .normal, title: "Share") { _,_,_ in
            let itemToShare = self.nameArrya[indexPath.row]
            let activitycontroller = UIActivityViewController(activityItems: [itemToShare], applicationActivities: nil)
            activitycontroller.popoverPresentationController?.sourceView = self.view
            activitycontroller.popoverPresentationController?.sourceRect = self.view.bounds
            self.present(activitycontroller, animated: true)
        }
        deleteAction.backgroundColor = .yellow
        deleteAction.image = UIImage(named: "")
        editAction.image = UIImage(systemName: "pencil")
        let configure = UISwipeActionsConfiguration(actions: [deleteAction,editAction,shareAction])
        return configure
    }
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedItem = nameArrya[sourceIndexPath.row]
        nameArrya.remove(at: sourceIndexPath.row)
        nameArrya.insert(movedItem, at: destinationIndexPath.row)
    }
}

