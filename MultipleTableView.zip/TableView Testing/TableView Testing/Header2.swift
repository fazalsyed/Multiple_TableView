//
//  Header2.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 07/04/23.
//

import UIKit

class Header2: UITableViewHeaderFooterView {

    @IBOutlet var mylbl: UILabel!
    
}
