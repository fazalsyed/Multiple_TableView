//
//  CellT_Country.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 07/04/23.
//

import UIKit

class CellT_Country: UITableViewCell {

    @IBOutlet var lblCountry: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
