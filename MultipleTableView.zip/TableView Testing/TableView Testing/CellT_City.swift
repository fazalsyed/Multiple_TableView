//
//  CellT_City.swift
//  TableView Testing
//
//  Created by syed fazal abbas on 07/04/23.
//

import UIKit

class CellT_City: UITableViewCell {

    @IBOutlet var lblCity: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
